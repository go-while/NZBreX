git clone https://github.com/animetosho/rapidyenc.git || exit 1
